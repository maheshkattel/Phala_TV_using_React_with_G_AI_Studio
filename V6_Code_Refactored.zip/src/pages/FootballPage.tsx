import { useState, useEffect } from 'react';
import { Sidebar } from '../components/Sidebar';
import { FootballView } from '../components/FootballView';
import { matchesLeagues } from '../config/leagues';

export function FootballPage() {
  const [selectedLeague, setSelectedLeague] = useState('Premier League');
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(
    typeof window !== 'undefined' && window.innerWidth >= 768
  );

  // Safely auto-ensure the active selected league is valid for match rendering
  useEffect(() => {
    const isValid = matchesLeagues.some(l => l.name === selectedLeague);
    if (!isValid) {
      setSelectedLeague('Premier League');
    }
  }, [selectedLeague]);

  return (
    <div className="flex flex-1 overflow-hidden relative" id="football-page">
      <Sidebar 
        leagues={matchesLeagues} 
        selectedLeague={selectedLeague} 
        onSelect={setSelectedLeague} 
        isExpanded={isSidebarExpanded}
        onToggle={() => setIsSidebarExpanded(!isSidebarExpanded)}
      />
      <FootballView selectedLeague={selectedLeague} />
    </div>
  );
}

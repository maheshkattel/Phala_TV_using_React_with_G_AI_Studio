import React from 'react';

interface GenericPageProps {
  title: string;
}

export const GenericPage: React.FC<GenericPageProps> = ({ title }) => {
  return (
    <div className="flex flex-1 w-full items-center justify-center min-h-[400px] p-6 bg-surface-panel" id="generic-page">
      <div className="text-center space-y-4 max-w-md animate-fade-in">
        <div className="w-16 h-16 bg-surface-card rounded-full border border-border-subtle flex items-center justify-center mx-auto text-xl font-bold text-primary shadow-sm">
          🏆
        </div>
        <h2 className="text-3xl font-extrabold text-white tracking-tight">{title}</h2>
        <p className="text-sm text-gray-400 leading-relaxed">
          The content and dynamic feeds for the <strong className="text-primary">{title}</strong> panel will be integrated and rendered here shortly.
        </p>
      </div>
    </div>
  );
};

import { useState, useEffect } from 'react';
import { Sidebar } from '../components/Sidebar';

// Reusing same leagues as App aligned with the user assets
const staticLeagues = [
  { name: 'Champions League', id: 7 },
  { name: 'Europa League', id: 679 },
  { name: 'Conference League', id: 17015 },
  { name: 'Premier League', id: 17 },
  { name: 'Laliga', id: 8 },
  { name: 'Serie A', id: 23 },
  { name: 'Bundesliga', id: 35 },
  { name: 'Ligue 1', id: 34 },
  { name: 'Saudi Pro League', id: 955 },
  { name: 'FIFA World Cup', id: 16 },
  { name: 'IPL', id: 11165 }
];

const leagueFileMap: Record<string, string> = {
  'Champions League': 'championsleague.json',
  'Europa League': 'europaleague.json',
  'Conference League': 'conferenceleague.json',
  'Premier League': 'premierleague.json',
  'Laliga': 'laliga.json',
  'Serie A': 'seriea.json',
  'Bundesliga': 'bundesliga.json',
  'Ligue 1': 'ligue1.json',
  'Saudi Pro League': 'saudiproleague.json',
  'FIFA World Cup': 'wc2026.json',
  'IPL': 'ipl.json'
};

function getPromotionLogoUrl(promotionText: string, currentLeagueId?: number): string | null {
  const text = promotionText.toLowerCase();
  
  if (text.includes('champions league elite')) {
    return 'https://api.sofascore.app/api/v1/unique-tournament/463/image';
  }
  if (text.includes('champions league 2') || text.includes('champions league two')) {
    return 'https://api.sofascore.app/api/v1/unique-tournament/668/image';
  }
  if (text.includes('champions league') || text.includes('ucl')) {
    return 'https://api.sofascore.app/api/v1/unique-tournament/7/image';
  }
  if (text.includes('europa league') || text.includes('uel')) {
    return 'https://api.sofascore.app/api/v1/unique-tournament/679/image';
  }
  if (text.includes('conference league') || text.includes('uecl')) {
    return 'https://api.sofascore.app/api/v1/unique-tournament/17015/image';
  }
  if (text.includes('playoffs') || text.includes('play-off') || text.includes('play off')) {
    if (currentLeagueId) {
      return `https://api.sofascore.app/api/v1/unique-tournament/${currentLeagueId}/image`;
    }
    return 'https://api.sofascore.app/api/v1/unique-tournament/16/image'; // Default to WC/International style banner
  }
  return null;
}

function getPromotionInfo(row: any, selectedLeague: string) {
  if (row.promotion?.text) {
    return {
      text: row.promotion.text,
      isRelegation: row.promotion.text.toLowerCase().includes('relegation')
    };
  }

  // Manual fallbacks based on official league spots
  const pos = row.position;
  if (selectedLeague === 'Premier League') {
    if (pos <= 4) return { text: 'Champions League', isRelegation: false };
    if (pos === 5) return { text: 'UEFA Europa League', isRelegation: false };
    if (pos > 17) return { text: 'Relegation', isRelegation: true };
  }
  if (selectedLeague === 'Bundesliga') {
    if (pos <= 4) return { text: 'Champions League', isRelegation: false };
    if (pos === 5) return { text: 'UEFA Europa League', isRelegation: false };
    if (pos === 16) return { text: 'Relegation Playoffs', isRelegation: true };
    if (pos >= 17) return { text: 'Relegation', isRelegation: true };
  }
  if (selectedLeague === 'Laliga') {
    if (pos <= 4) return { text: 'Champions League', isRelegation: false };
    if (pos === 5) return { text: 'UEFA Europa League', isRelegation: false };
    if (pos > 17) return { text: 'Relegation', isRelegation: true };
  }
  if (selectedLeague === 'Serie A') {
    if (pos <= 4) return { text: 'Champions League', isRelegation: false };
    if (pos === 5) return { text: 'UEFA Europa League', isRelegation: false };
    if (pos > 17) return { text: 'Relegation', isRelegation: true };
  }
  if (selectedLeague === 'Ligue 1') {
    if (pos <= 3) return { text: 'Champions League', isRelegation: false };
    if (pos === 4) return { text: 'Champions League Qualification', isRelegation: false };
    if (pos === 5) return { text: 'UEFA Europa League', isRelegation: false };
    if (pos === 16) return { text: 'Relegation Playoffs', isRelegation: true };
    if (pos >= 17) return { text: 'Relegation', isRelegation: true };
  }
  if (selectedLeague === 'Saudi Pro League') {
    if (pos <= 3) return { text: 'Champions League Elite', isRelegation: false };
    if (pos === 4) return { text: 'Champions League 2', isRelegation: false };
    if (pos >= 16) return { text: 'Relegation', isRelegation: true };
  }
  if (selectedLeague === 'IPL') {
    if (pos <= 4) return { text: 'Playoffs', isRelegation: false };
  }
  return null;
}

function getPromotionStyles(promotionText: string, leagueName?: string): { borderClass: string; textClass: string; glowClass: string; imgClass?: string } {
  const text = promotionText.toLowerCase();
  const isQualification = text.includes('qualification') || text.includes('qualifying');

  if (text.includes('relegation')) {
    if (text.includes('playoffs') || text.includes('play-off') || text.includes('play off')) {
      return {
        borderClass: 'border-purple-500/30 bg-[#21153b]',
        textClass: 'text-purple-400',
        glowClass: 'drop-shadow-[0_0_4px_rgba(168,85,247,0.5)]',
        imgClass: ''
      };
    }
    return {
      borderClass: 'border-red-500/30 bg-[#1f0b0d]',
      textClass: 'text-red-400',
      glowClass: '',
      imgClass: ''
    };
  }

  if (text.includes('champions league elite')) {
    return {
      borderClass: isQualification ? 'border-amber-500/15 bg-[#1b1509]' : 'border-amber-500/30 bg-[#2d2209]',
      textClass: isQualification ? 'text-amber-500/60' : 'text-amber-400',
      glowClass: isQualification ? 'opacity-40' : 'drop-shadow-[0_0_5px_rgba(245,158,11,0.6)] animate-pulse',
      imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
    };
  }
  if (text.includes('champions league 2') || text.includes('champions league two')) {
    return {
      borderClass: isQualification ? 'border-slate-500/15 bg-[#10141b]' : 'border-slate-400/30 bg-[#161c27]',
      textClass: isQualification ? 'text-slate-400/60' : 'text-slate-300',
      glowClass: isQualification ? 'opacity-40' : 'drop-shadow-[0_0_4px_rgba(148,163,184,0.5)]',
      imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
    };
  }

  if (text.includes('champions league') || text.includes('ucl')) {
    return {
      borderClass: isQualification ? 'border-sky-500/10 bg-[#07101e]' : 'border-blue-500/30 bg-[#0c1a30]',
      textClass: isQualification ? 'text-sky-500/60' : 'text-blue-400',
      glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(96,165,250,0.6)] animate-pulse',
      imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
    };
  }
  if (text.includes('europa league') || text.includes('uel')) {
    return {
      borderClass: isQualification ? 'border-amber-500/15 bg-[#1b1109]' : 'border-amber-500/30 bg-[#2d1b0d]',
      textClass: isQualification ? 'text-amber-500/60' : 'text-amber-500',
      glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(245,158,11,0.6)]',
      imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
    };
  }
  if (text.includes('conference league') || text.includes('uecl')) {
    return {
      borderClass: isQualification ? 'border-emerald-500/15 bg-[#07130e]' : 'border-emerald-500/30 bg-[#0e241b]',
      textClass: isQualification ? 'text-emerald-400/60' : 'text-emerald-400',
      glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(16,185,129,0.6)]',
      imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
    };
  }
  if (text.includes('playoffs') || text.includes('play-off') || text.includes('play off')) {
    const activeLeague = leagueName ? leagueName.toLowerCase() : '';
    
    if (activeLeague.includes('champions league') || activeLeague.includes('ucl')) {
      return {
        borderClass: isQualification ? 'border-sky-500/10 bg-[#07101e]' : 'border-blue-500/30 bg-[#0c1a30]',
        textClass: isQualification ? 'text-sky-500/60' : 'text-blue-400',
        glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(96,165,250,0.6)] animate-pulse',
        imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
      };
    }
    if (activeLeague.includes('europa league') || activeLeague.includes('uel')) {
      return {
        borderClass: isQualification ? 'border-amber-500/15 bg-[#1b1109]' : 'border-amber-500/30 bg-[#2d1b0d]',
        textClass: isQualification ? 'text-amber-500/60' : 'text-amber-500',
        glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(245,158,11,0.6)]',
        imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
      };
    }
    if (activeLeague.includes('conference league') || activeLeague.includes('uecl')) {
      return {
        borderClass: isQualification ? 'border-emerald-500/15 bg-[#07130e]' : 'border-emerald-500/30 bg-[#0e241b]',
        textClass: isQualification ? 'text-emerald-400/60' : 'text-emerald-400',
        glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(16,185,129,0.6)]',
        imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
      };
    }

    return {
      borderClass: isQualification ? 'border-purple-500/15 bg-[#140b24]' : 'border-purple-500/30 bg-[#21153b]',
      textClass: isQualification ? 'text-purple-500/60' : 'text-purple-400',
      glowClass: isQualification ? 'opacity-40 brightness-75' : 'drop-shadow-[0_0_4px_rgba(168,85,247,0.5)]',
      imgClass: isQualification ? 'opacity-30 saturate-50 brightness-50 contrast-125 select-none grayscale' : ''
    };
  }
  return {
    borderClass: 'border-blue-500/20 bg-surface-bg',
    textClass: 'text-blue-400',
    glowClass: '',
    imgClass: ''
  };
}

export function StandingsPage() {
  const [selectedLeague, setSelectedLeague] = useState('FIFA World Cup');
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(typeof window !== 'undefined' && window.innerWidth >= 768);
  const [leagueData, setLeagueData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const filename = leagueFileMap[selectedLeague];
    if (!filename) {
      setLeagueData(null);
      setError(`No file configured for ${selectedLeague}`);
      return;
    }

    setIsLoading(true);
    setError(null);
    fetch(`https://maheshkattel.github.io/livestream/soccer/standings/${filename}`)
      .then(res => {
        if (!res.ok) {
          throw new Error(`Failed to load ${selectedLeague} standings`);
        }
        return res.json();
      })
      .then(data => {
        setLeagueData(data);
        setIsLoading(false);
      })
      .catch(err => {
        console.error("Failed to fetch standings:", err);
        setError(err.message || "An error occurred while loading data.");
        setIsLoading(false);
      });
  }, [selectedLeague]);

  const displayGroups = leagueData?.standings || [];
  const isCricket = selectedLeague === 'IPL';

  const legendItems: { logoUrl: string | null; text: string; style: any; isRelegation: boolean }[] = [];
  const seenTexts = new Set<string>();

  displayGroups.forEach((group: any) => {
    group.rows?.forEach((row: any) => {
      const promInfo = getPromotionInfo(row, selectedLeague);
      if (promInfo) {
        const { text: promotionText, isRelegation } = promInfo;
        if (!seenTexts.has(promotionText)) {
          seenTexts.add(promotionText);
          const currentLeagueObj = staticLeagues.find(l => l.name === selectedLeague);
          const logoUrl = getPromotionLogoUrl(promotionText, currentLeagueObj?.id);
          const styles = getPromotionStyles(promotionText, selectedLeague);
          legendItems.push({
            logoUrl: isRelegation ? null : logoUrl,
            text: promotionText,
            style: styles,
            isRelegation
          });
        }
      }
    });
  });

  legendItems.sort((a, b) => {
    if (a.isRelegation && !b.isRelegation) return 1;
    if (!a.isRelegation && b.isRelegation) return -1;
    return a.text.localeCompare(b.text);
  });

  return (
    <div className="flex flex-1 overflow-hidden relative" id="standings-page">
      <Sidebar 
        leagues={staticLeagues} 
        selectedLeague={selectedLeague} 
        onSelect={setSelectedLeague} 
        isExpanded={isSidebarExpanded}
        onToggle={() => setIsSidebarExpanded(!isSidebarExpanded)}
      />
      <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-surface-panel text-white">
        {isLoading ? (
          <div className="flex items-center justify-center h-64 mt-12" id="standings-loading">
            <div className="flex flex-col items-center gap-3">
              <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm text-muted">Loading {selectedLeague} standings...</p>
            </div>
          </div>
        ) : error ? (
          <div className="flex items-center justify-center h-64 mt-12" id="standings-error">
            <div className="text-center space-y-2">
              <p className="text-[#ef4444] font-semibold">{error}</p>
              <p className="text-xs text-muted">Please select another league or check your internet connection.</p>
            </div>
          </div>
        ) : displayGroups && displayGroups.length > 0 ? (
          <div className="space-y-8 max-w-4xl mx-auto pb-10" id="standings-content">
            {displayGroups.map((group: any) => (
              <div key={group.id} className="bg-surface-card rounded-xl border border-border-subtle overflow-hidden shadow-sm">
                <div className="bg-surface-active px-4 py-3 font-semibold text-lg flex items-center border-b border-border-subtle">
                  {group.name}
                </div>
                <div className="overflow-x-auto scrollbar-hide">
                  <table className="w-full text-left border-collapse text-sm whitespace-nowrap">
                    <thead>
                      <tr className="border-b border-border-subtle text-muted">
                        <th className="px-4 py-3 font-medium w-8 text-center text-muted">#</th>
                        <th className="px-4 py-3 font-medium min-w-[140px] text-muted">Team</th>
                        <th className="px-2 sm:px-4 py-3 font-medium text-center text-muted">P</th>
                        <th className="px-2 sm:px-4 py-3 font-medium text-center text-muted">W</th>
                        {isCricket ? (
                          <th className="px-2 sm:px-4 py-3 font-medium text-center text-muted hidden sm:table-cell" title="No Result">NR</th>
                        ) : (
                          <th className="px-2 sm:px-4 py-3 font-medium text-center text-muted hidden sm:table-cell">D</th>
                        )}
                        <th className="px-2 sm:px-4 py-3 font-medium text-center text-muted">L</th>
                        {!isCricket && (
                          <th className="px-4 py-3 font-medium text-center text-muted hidden md:table-cell">Goals</th>
                        )}
                        {isCricket ? (
                          <th className="px-4 py-3 font-medium text-center text-muted hidden md:table-cell">NRR</th>
                        ) : (
                          <th className="px-4 py-3 font-medium text-center text-muted hidden md:table-cell">+/-</th>
                        )}
                        <th className="px-2 sm:px-4 py-3 font-medium text-center text-white">Pts</th>
                        <th className="px-4 py-3 font-medium text-center text-muted hidden lg:table-cell">Form</th>
                      </tr>
                    </thead>
                    <tbody>
                      {group.rows.map((row: any) => {
                        const promInfo = getPromotionInfo(row, selectedLeague);
                        const promotionText = promInfo?.text || null;
                        const isRelegation = promInfo ? promInfo.isRelegation : false;
                        const currentLeagueObj = staticLeagues.find(l => l.name === selectedLeague);
                        const promotionLogoUrl = promotionText ? getPromotionLogoUrl(promotionText, currentLeagueObj?.id) : null;
                        const styles = promotionText ? getPromotionStyles(promotionText, selectedLeague) : null;

                        return (
                          <tr key={row.team.id} className="border-b border-border-subtle hover:bg-surface-active/50 transition-colors last:border-0">
                            <td className="px-4 py-3 text-center">
                               <div className="flex items-center justify-center">
                                 {promotionLogoUrl ? (
                                    <div className="relative group flex items-center justify-center w-7 h-7 cursor-help" title={`Qualifies for ${promotionText} (Position: ${row.position})`}>
                                      <img
                                        src={promotionLogoUrl}
                                        alt={promotionText}
                                        className={`w-5 h-5 object-contain transition-all duration-300 group-hover:scale-110 ${styles?.glowClass || ''} ${styles?.imgClass || ''}`}
                                        referrerPolicy="no-referrer"
                                        onError={(e) => {
                                          (e.target as HTMLImageElement).style.display = 'none';
                                        }}
                                      />
                                      <span className={`absolute -bottom-1 -right-1 border border-border-subtle ${styles?.borderClass || 'bg-surface-card border-border-subtle'} ${styles?.textClass || 'text-white'} text-[8px] w-3.5 h-3.5 rounded-full flex items-center justify-center font-extrabold shadow-md leading-none`}>
                                        {row.position}
                                      </span>
                                      <span className="hidden group-hover:flex absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-surface-card border border-border-subtle rounded-md text-[10px] font-bold text-white whitespace-nowrap shadow-xl z-20">
                                        Qualifies for {promotionText}
                                      </span>
                                    </div>
                                 ) : isRelegation ? (
                                    <span className={`w-6 h-6 rounded-full ${styles?.borderClass || 'bg-red-500/20 border-red-500/30'} ${styles?.textClass || 'text-red-400'} border flex items-center justify-center text-xs font-bold`} title={promotionText || "Relegation Zone"}>
                                      {row.position}
                                    </span>
                                 ) : row.position <= 4 ? (
                                    <span className="w-6 h-6 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center text-xs font-bold">
                                      {row.position}
                                    </span>
                                 ) : (
                                    <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium text-gray-400">
                                      {row.position}
                                    </span>
                                 )}
                               </div>
                            </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-3">
                              <img 
                                src={`https://api.sofascore.app/api/v1/team/${row.team.id}/image`} 
                                alt={row.team.name} 
                                className="w-6 h-6 object-contain"
                                referrerPolicy="no-referrer"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBjbGFzcz0ibHVjaWRlIGx1Y2lkZS1zaGllbGQiPjxwYXRoIGQ9Ik0xMiAyMnM4LTQgOC0xMFYzTDEyIDIgNCAzdjljMCA2IDggMTAgOCAxMHoiLz48L3N2Zz4=';
                                }}
                              />
                              <span className="font-medium hidden md:block">{row.team.name}</span>
                              <span className="font-medium md:hidden">{row.team.shortName || row.team.name}</span>
                            </div>
                          </td>
                          <td className="px-2 sm:px-4 py-3 text-center text-muted">{row.matches}</td>
                          <td className="px-2 sm:px-4 py-3 text-center text-muted">{row.wins}</td>
                          {isCricket ? (
                            <td className="px-2 sm:px-4 py-3 text-center text-muted hidden sm:table-cell">{row.noResult ?? 0}</td>
                          ) : (
                            <td className="px-2 sm:px-4 py-3 text-center text-muted hidden sm:table-cell">{row.draws}</td>
                          )}
                          <td className="px-2 sm:px-4 py-3 text-center text-muted">{row.losses}</td>
                          {!isCricket && (
                            <td className="px-4 py-3 text-center text-muted hidden md:table-cell">{row.scoresFor}:{row.scoresAgainst}</td>
                          )}
                          {isCricket ? (
                            <td className="px-4 py-3 text-center text-muted hidden md:table-cell">
                              {row.netRunRate !== undefined ? (row.netRunRate > 0 ? `+${row.netRunRate.toFixed(3)}` : row.netRunRate.toFixed(3)) : '0.000'}
                            </td>
                          ) : (
                            <td className="px-4 py-3 text-center text-muted hidden md:table-cell">{row.scoreDiffFormatted}</td>
                          )}
                          <td className="px-2 sm:px-4 py-3 text-center font-bold text-white max-w-[60px]">{row.points}</td>
                          <td className="px-4 py-3 text-center hidden lg:table-cell">
                            <div className="flex items-center justify-center gap-1">
                              {row.last5?.map((result: string, i: number) => (
                                <span key={i} className={`w-[18px] h-[18px] rounded-[3px] flex items-center justify-center text-[9px] font-bold text-white ${
                                  result === 'W' ? 'bg-green-500' : result === 'D' ? 'bg-zinc-500' : 'bg-red-500'
                                }`}>
                                  {result}
                                </span>
                              ))}
                            </div>
                          </td>
                        </tr>
                      );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
            {legendItems.length > 0 && (
              <div className="bg-surface-card rounded-xl border border-border-subtle p-5 shadow-sm space-y-4">
                <h4 className="text-xs font-semibold text-muted uppercase tracking-wider">Qualification & Zone Key</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {legendItems.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3">
                      {item.isRelegation ? (
                        <div className="relative flex items-center justify-center w-6 h-6">
                          <span className={`w-5 h-5 rounded-full ${item.style?.borderClass || 'bg-red-500/20 border-red-500/30'} ${item.style?.textClass || 'text-red-400'} border flex items-center justify-center text-[10px] font-bold`}>
                            #
                          </span>
                        </div>
                      ) : item.logoUrl ? (
                        <div className="relative flex items-center justify-center w-6 h-6 bg-surface-active/30 rounded-md p-0.5 border border-border-subtle/50">
                          <img
                            src={item.logoUrl}
                            alt={item.text}
                            className={`w-4 h-4 object-contain ${item.style?.glowClass || ''} ${item.style?.imgClass || ''}`}
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        </div>
                      ) : (
                        <div className="relative flex items-center justify-center w-6 h-6">
                          <span className="w-5 h-5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center justify-center text-[10px] font-bold">
                            #
                          </span>
                        </div>
                      )}
                      <span className="text-xs font-medium text-gray-300 leading-snug">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-bold text-white">{selectedLeague}</h2>
              <p className="text-muted">Standings data for {selectedLeague} will be displayed here.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

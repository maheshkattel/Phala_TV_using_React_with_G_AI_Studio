import { useState, useEffect } from 'react';
import { Sidebar } from '../components/Sidebar';
import { FootballView } from '../components/FootballView';
import { cricketLeagues } from '../config/leagues';

export function CricketPage() {
  const [selectedLeague, setSelectedLeague] = useState('IPL');
  const [isSidebarExpanded, setIsSidebarExpanded] = useState(
    typeof window !== 'undefined' && window.innerWidth >= 768
  );

  // Safely auto-ensure the active selected league is valid for Cricket rendering
  useEffect(() => {
    if (selectedLeague !== 'IPL') {
      setSelectedLeague('IPL');
    }
  }, [selectedLeague]);

  return (
    <div className="flex flex-1 overflow-hidden relative" id="cricket-page">
      <Sidebar 
        leagues={cricketLeagues} 
        selectedLeague={selectedLeague} 
        onSelect={setSelectedLeague} 
        isExpanded={isSidebarExpanded}
        onToggle={() => setIsSidebarExpanded(!isSidebarExpanded)}
      />
      <FootballView selectedLeague={selectedLeague} />
    </div>
  );
}

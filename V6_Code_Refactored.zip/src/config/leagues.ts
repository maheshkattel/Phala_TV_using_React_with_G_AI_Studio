export const matchFileMap: Record<string, string> = {
  'Champions League': 'championsleague.json',
  'Europa League': 'europaleague.json',
  'Conference League': 'conferenceleague.json',
  'Premier League': 'premierleague.json',
  'Laliga': 'laliga.json',
  'Serie A': 'seriea.json',
  'Bundesliga': 'bundesliga.json',
  'Ligue 1': 'ligue1.json',
  'Saudi Pro League': 'saudiproleague.json',
  'FIFA World Cup': 'wc2026.json',
  'IPL': 'ipl.json'
};

export const staticLeagues = [
  { name: 'Champions League', id: 7 },
  { name: 'Europa League', id: 679 },
  { name: 'Premier League', id: 17 },
  { name: 'Laliga', id: 8 },
  { name: 'Serie A', id: 23 },
  { name: 'Bundesliga', id: 35 },
  { name: 'Ligue 1', id: 34 },
  { name: 'Saudi Pro League', id: 955 },
  { name: 'Conference League', id: 17015 },
  { name: 'FIFA World Cup', id: 16 },
  { name: 'IPL', id: 11165 }
];

export const matchesLeagues = [
  { name: 'Premier League', id: 17 },
  { name: 'FIFA World Cup', id: 16 },
  { name: 'Serie A', id: 23 }
];

export const cricketLeagues = [
  { name: 'IPL', id: 11165 }
];

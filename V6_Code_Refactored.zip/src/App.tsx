import { useLocation, useNavigate } from 'react-router-dom';
import { TopNav } from './components/TopNav';
import { FootballPage } from './pages/FootballPage';
import { StandingsPage } from './pages/StandingsPage';
import { CricketPage } from './pages/CricketPage';
import { GenericPage } from './pages/GenericPage';

export default function App() {
  const location = useLocation();
  const navigate = useNavigate();

  const getNavFromPath = (path: string) => {
    if (path === '/standings') return 'Standings';
    if (path === '/cricket') return 'Cricket';
    if (path === '/' || path === '') return 'Football';
    const slug = path.slice(1);
    return slug.charAt(0).toUpperCase() + slug.slice(1);
  };

  const selectedNav = getNavFromPath(location.pathname);

  const handleSelectNav = (nav: string) => {
    if (nav === 'Football') {
      navigate('/');
    } else {
      navigate(`/${nav.toLowerCase()}`);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-surface-bg text-muted font-sans overflow-hidden" id="app-root">
      <TopNav selectedNav={selectedNav} onSelectNav={handleSelectNav} />
      <div className="flex flex-1 overflow-hidden relative">
        {selectedNav === 'Football' ? (
          <FootballPage />
        ) : selectedNav === 'Standings' ? (
          <StandingsPage />
        ) : selectedNav === 'Cricket' ? (
          <CricketPage />
        ) : (
          <GenericPage title={selectedNav} />
        )}
      </div>
    </div>
  );
}

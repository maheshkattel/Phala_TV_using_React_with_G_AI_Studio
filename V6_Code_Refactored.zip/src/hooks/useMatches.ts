import { useState, useEffect, useMemo } from 'react';
import { SportEvent } from '../types';
import { matchFileMap } from '../config/leagues';

export function useMatches(selectedLeague: string) {
  const [events, setEvents] = useState<SportEvent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedRound, setSelectedRound] = useState<number | 'All'>('All');

  // Load and normalize events when selected league changes
  useEffect(() => {
    const filename = matchFileMap[selectedLeague];
    if (!filename) {
      setEvents([]);
      setError(`No match file configured for ${selectedLeague}`);
      return;
    }

    setIsLoading(true);
    setError(null);

    fetch(`https://maheshkattel.github.io/livestream/soccer/matches/${filename}`)
      .then(res => {
        if (!res.ok) {
          throw new Error(`Failed to load matches for ${selectedLeague}`);
        }
        return res.json();
      })
      .then(data => {
        if (data && Array.isArray(data.events)) {
          const now = Math.floor(Date.now() / 1000);
          const normalizedEvents = data.events.map((event: SportEvent) => {
            if (typeof event.startTimestamp === 'number') {
              let statusDescription = event.status?.description || 'Ended';
              let statusType = event.status?.type || 'finished';

              if (now < event.startTimestamp) {
                statusDescription = 'Not started';
                statusType = 'notstarted';
              } else if (now >= event.startTimestamp && now < event.startTimestamp + 115 * 60) {
                statusDescription = 'Live';
                statusType = 'inprogress';
              } else {
                statusDescription = 'Ended';
                statusType = 'finished';
              }

              return {
                ...event,
                status: {
                  ...event.status,
                  description: statusDescription,
                  type: statusType
                }
              };
            }
            return event;
          });
          setEvents(normalizedEvents);
        } else {
          setEvents([]);
        }
      })
      .catch(err => {
        console.error(`Live match sync failed for ${selectedLeague}:`, err);
        setError(`Failed to fetch live matches for ${selectedLeague}`);
        setEvents([]);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, [selectedLeague]);

  // Reset selected round when league switches
  useEffect(() => {
    setSelectedRound('All');
  }, [selectedLeague]);

  // Derive dynamic list of available rounds
  const availableRounds = useMemo(() => {
    const rounds = new Set<number>();
    events.forEach(e => {
      if (e.roundInfo?.round) {
        rounds.add(e.roundInfo.round);
      }
    });
    return Array.from(rounds).sort((a, b) => a - b);
  }, [events]);

  // Filter and sort events based on Round + live priority
  const filteredEvents = useMemo(() => {
    let result = events;
    if (selectedRound !== 'All') {
      result = events.filter(e => e.roundInfo?.round === selectedRound);
    }

    // Sort: Live (inprogress) first, then Not started (notstarted), then Ended (finished)
    return [...result].sort((a, b) => {
      const typeA = a.status?.type || 'finished';
      const typeB = b.status?.type || 'finished';

      const priority = {
        'inprogress': 1,
        'notstarted': 2,
        'finished': 3
      };

      const pA = priority[typeA as keyof typeof priority] || 3;
      const pB = priority[typeB as keyof typeof priority] || 3;

      if (pA !== pB) {
        return pA - pB;
      }

      const timeA = a.startTimestamp || 0;
      const timeB = b.startTimestamp || 0;

      if (typeA === 'notstarted') {
        return timeA - timeB; // Upcoming: soonest first
      } else if (typeA === 'finished') {
        return timeB - timeA; // Ended: completed most recently first
      } else {
        return timeA - timeB; // Live: start time chronological
      }
    });
  }, [events, selectedRound]);

  // Round selector controllers
  const handlePrevRound = () => {
    if (availableRounds.length === 0) return;
    if (selectedRound === 'All') {
      setSelectedRound(availableRounds[availableRounds.length - 1]);
    } else {
      const idx = availableRounds.indexOf(selectedRound);
      if (idx === 0) {
        setSelectedRound('All');
      } else {
        setSelectedRound(availableRounds[idx - 1]);
      }
    }
  };

  const handleNextRound = () => {
    if (availableRounds.length === 0) return;
    if (selectedRound === 'All') {
      setSelectedRound(availableRounds[0]);
    } else {
      const idx = availableRounds.indexOf(selectedRound);
      if (idx === availableRounds.length - 1) {
        setSelectedRound('All');
      } else {
        setSelectedRound(availableRounds[idx + 1]);
      }
    }
  };

  return {
    events,
    isLoading,
    error,
    selectedRound,
    setSelectedRound,
    availableRounds,
    filteredEvents,
    handlePrevRound,
    handleNextRound
  };
}

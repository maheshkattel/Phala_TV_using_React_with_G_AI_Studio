import React from 'react';

interface RoundSelectorProps {
  availableRounds: number[];
  selectedRound: number | 'All';
  setSelectedRound: (round: number | 'All') => void;
  onPrevRound: () => void;
  onNextRound: () => void;
}

export const RoundSelector: React.FC<RoundSelectorProps> = ({
  availableRounds,
  selectedRound,
  setSelectedRound,
  onPrevRound,
  onNextRound
}) => {
  if (availableRounds.length === 0) return null;

  return (
    <div className="flex items-center gap-2 bg-surface-card/60 p-1 rounded-xl border border-border-subtle shadow-sm select-none" id="round-selector">
      <button 
        onClick={onPrevRound}
        className="px-4 py-1.5 bg-surface-active hover:bg-primary hover:text-white border border-border-subtle text-gray-300 rounded-lg text-xs font-semibold transition-all shadow-sm active:scale-95"
        id="round-prev-btn"
      >
        Prev
      </button>
      <button 
        onClick={() => setSelectedRound('All')}
        className="px-5 py-1.5 bg-transparent text-white text-xs font-bold hover:text-primary transition-colors cursor-pointer"
        title="Click to reset filter and show all rounds"
        id="round-reset-btn"
      >
        {selectedRound === 'All' ? 'All Rounds' : `Round ${selectedRound}`}
      </button>
      <button 
        onClick={onNextRound}
        className="px-4 py-1.5 bg-surface-active hover:bg-primary hover:text-white border border-border-subtle text-gray-300 rounded-lg text-xs font-semibold transition-all shadow-sm active:scale-95"
        id="round-next-btn"
      >
        Next
      </button>
    </div>
  );
};

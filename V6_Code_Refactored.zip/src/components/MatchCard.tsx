import { SportEvent } from '../types';
import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

function formatCountdown(targetTimestamp: number) {
  const diff = targetTimestamp * 1000 - Date.now();
  if (diff <= 0) return { text: 'Started', isUrgent: false };

  const d = Math.floor(diff / (1000 * 60 * 60 * 24));
  const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const m = Math.floor((diff / 1000 / 60) % 60);
  const s = Math.floor((diff / 1000) % 60);

  const isUrgent = diff > 0 && diff < 1000 * 60 * 60;

  if (d > 0) return { text: `${d}d ${h}h ${m}m`, isUrgent };
  return { text: `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`, isUrgent };
}

export function MatchCard({ event }: { event: SportEvent }) {
  const date = new Date(event.startTimestamp * 1000);
  const timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const [countdownState, setCountdownState] = useState(formatCountdown(event.startTimestamp));

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdownState(formatCountdown(event.startTimestamp));
    }, 1000);
    return () => clearInterval(interval);
  }, [event.startTimestamp]);

  const { text: countdown, isUrgent } = countdownState;

  return (
    <div className="bg-surface-card rounded-xl p-5 flex flex-col gap-4 shadow-sm border border-border-subtle hover:border-border-hover transition-colors">
      <div className="flex justify-between items-center pb-3 border-b border-border-subtle">
          <span className="text-xs text-gray-400 font-medium truncate pr-4">{event.tournament.name}</span>
          <span className={`text-[10px] flex items-center gap-1.5 font-bold tracking-wide uppercase px-2 py-0.5 rounded shrink-0 ${
            event.status.description === 'Not started'
              ? (isUrgent ? 'text-timer-urgent bg-timer-urgent-bg' : 'text-timer-normal bg-timer-normal-bg')
              : 'text-accent bg-accent/10'
          }`}>
            {event.status.description === 'Not started' && <Clock size={12} />}
            {event.status.description === 'Not started' ? countdown : event.status.description}
          </span>
      </div>

      <div className="flex items-center justify-between py-1">
        <div className="flex flex-col gap-3.5 flex-1 pr-4 border-r border-border-subtle">
          <div className="flex items-center gap-3 group">
              <div className="w-7 h-7 flex items-center justify-center shrink-0">
                  <img 
                    src={`https://i1.wp.com/api.sofascore1.com/api/v1/team/${event.homeTeam.id}/image`}
                    alt={event.homeTeam.name}
                    className="w-full h-full object-contain drop-shadow-sm"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBjbGFzcz0ibHVjaWRlIGx1Y2lkZS1zaGllbGQiPjxwYXRoIGQ9Ik0xMiAyMnM4LTQgOC0xMFYzTDEyIDIgNCAzdjljMCA2IDggMTAgOCAxMHoiLz48L3N2Zz4='; // fallback shield
                    }}
                  />
              </div>
              <span className="font-semibold text-gray-100 text-[14px] flex items-center gap-1.5">
                {event.homeTeam.name}
                {event.homeRedCards && event.homeRedCards > 0 && (
                  <span className="w-2.5 h-3.5 bg-red-600 rounded-sm inline-block shadow-sm" title={`${event.homeRedCards} Red Card`} />
                )}
              </span>
          </div>
          
          <div className="flex items-center gap-3 group">
              <div className="w-7 h-7 flex items-center justify-center shrink-0">
                  <img 
                    src={`https://i1.wp.com/api.sofascore1.com/api/v1/team/${event.awayTeam.id}/image`}
                    alt={event.awayTeam.name}
                    className="w-full h-full object-contain drop-shadow-sm"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBjbGFzcz0ibHVjaWRlIGx1Y2lkZS1zaGllbGQiPjxwYXRoIGQ9Ik0xMiAyMnM4LTQgOC0xMFYzTDEyIDIgNCAzdjljMCA2IDggMTAgOCAxMHoiLz48L3N2Zz4='; // fallback shield
                    }}
                  />
              </div>
              <span className="font-semibold text-gray-100 text-[14px] flex items-center gap-1.5">
                {event.awayTeam.name}
                {event.awayRedCards && event.awayRedCards > 0 && (
                  <span className="w-2.5 h-3.5 bg-red-600 rounded-sm inline-block shadow-sm" title={`${event.awayRedCards} Red Card`} />
                )}
              </span>
          </div>
        </div>
        
        {event.status.description === 'Not started' ? (
          <div className="flex flex-col items-end justify-center pl-4 w-24 shrink-0 text-right">
            <span className="text-gray-400 text-xs font-medium">{date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
            <span className="text-gray-200 text-sm font-semibold mt-0.5">{timeString}</span>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center pl-4 w-24 shrink-0 text-center">
            <span className="text-accent text-xl font-bold tracking-wider">
              {event.homeScore !== undefined ? event.homeScore.display : '-'} : {event.awayScore !== undefined ? event.awayScore.display : '-'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

import React from 'react';
import { useMatches } from '../hooks/useMatches';
import { RoundSelector } from './RoundSelector';
import { MatchesGrid } from './MatchesGrid';

interface FootballViewProps {
  selectedLeague: string;
}

export const FootballView: React.FC<FootballViewProps> = ({ selectedLeague }) => {
  const {
    events,
    isLoading,
    error,
    selectedRound,
    setSelectedRound,
    availableRounds,
    filteredEvents,
    handlePrevRound,
    handleNextRound
  } = useMatches(selectedLeague);

  return (
    <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-surface-panel animate-fade-in" id="football-view-content">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-border-subtle/40">
        <div className="flex items-center gap-3">
          <h2 className="text-xl font-bold text-white tracking-tight">{selectedLeague} Matches</h2>
          {isLoading && (
            <span className="text-[11px] font-bold text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-full animate-pulse tracking-wide select-none">
              Syncing live...
            </span>
          )}
        </div>
        <RoundSelector
          availableRounds={availableRounds}
          selectedRound={selectedRound}
          setSelectedRound={setSelectedRound}
          onPrevRound={handlePrevRound}
          onNextRound={handleNextRound}
        />
      </div>

      <MatchesGrid
        isLoading={isLoading}
        error={error}
        events={events}
        filteredEvents={filteredEvents}
        selectedLeague={selectedLeague}
      />
    </main>
  );
};

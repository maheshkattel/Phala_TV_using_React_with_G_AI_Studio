interface TopNavProps {
  selectedNav: string;
  onSelectNav: (nav: string) => void;
}

export function TopNav({ selectedNav, onSelectNav }: TopNavProps) {
  const links = ['Football', 'Cricket', 'Live', 'Channels', 'Standings', 'News', 'Trending', 'Highlights'];

  return (
    <header className="h-14 bg-surface-topnav border-b border-border-subtle shrink-0 flex items-center w-full overflow-x-auto scrollbar-hide">
      <div className="flex gap-2 sm:gap-6 min-w-max md:min-w-0 w-full px-4 [justify-content:safe_center] text-[13px] sm:text-sm">
        {links.map((link) => (
          <button 
            key={link} 
            onClick={() => onSelectNav(link)} 
            className={`font-medium px-4 py-1.5 whitespace-nowrap transition-colors ${link === selectedNav ? 'bg-primary text-white rounded' : 'text-gray-400 hover:text-white'}`}
          >
            {link}
          </button>
        ))}
      </div>
    </header>
  );
}

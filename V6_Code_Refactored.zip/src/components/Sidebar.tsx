import { ChevronLeft, ChevronRight } from 'lucide-react';

interface League {
  name: string;
  id: number;
}

interface SidebarProps {
  leagues: League[];
  selectedLeague: string;
  onSelect: (league: string) => void;
  isExpanded: boolean;
  onToggle: () => void;
}

export function Sidebar({ leagues, selectedLeague, onSelect, isExpanded, onToggle }: SidebarProps) {
  return (
    <>
      <div className={`bg-surface-sidebar flex flex-col border-r border-border-subtle shrink-0 h-full overflow-y-auto overflow-x-hidden scrollbar-hide transition-all duration-300 ${isExpanded ? 'w-64 absolute md:relative z-20 shadow-2xl md:shadow-none' : 'w-[72px]'}`}>
        <div className={`p-4 flex items-center border-b border-border-subtle h-[72px] ${isExpanded ? 'justify-between' : 'justify-center'}`}>
          {isExpanded && (
            <div className="flex items-center gap-2">
              <span className="font-bold text-xl text-white tracking-tight">Phala TV</span>
            </div>
          )}
          <button 
            onClick={onToggle}
            className={`${!isExpanded ? 'bg-white text-black' : 'text-gray-400 hover:text-white'} rounded-[10px] w-10 h-10 flex items-center justify-center transition-colors`}
          >
            {isExpanded ? <ChevronLeft size={20} /> : <ChevronRight size={22} strokeWidth={2.5} />}
          </button>
        </div>

        <div className="flex flex-col py-3 space-y-2">
          {leagues.map(league => {
            const isActive = league.name === selectedLeague;
            return (
              <button
                key={league.id}
                onClick={() => onSelect(league.name)}
                className={`relative mx-2 md:mx-3 flex items-center rounded-xl font-medium transition-colors ${
                  isActive ? 'bg-primary text-white' : 'text-muted hover:bg-surface-active/60 hover:text-white'
                } ${isExpanded ? 'justify-between px-3 py-2.5 text-sm' : 'justify-center w-12 h-12 self-center'}`}
              >
                <div className={`flex items-center gap-3 ${!isExpanded && 'justify-center w-full h-full'}`}>
                  <img 
                    src={`https://i1.wp.com/api.sofascore1.com/api/v1/unique-tournament/${league.id}/image`} 
                    alt={league.name}
                    className={`${isExpanded ? 'w-5 h-5' : 'w-7 h-7'} object-contain`}
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBjbGFzcz0ibHVjaWRlIGx1Y2lkZS10cm9waHkiPjxwYXRoIGQ9Ik02IDloMTJNNyAydjE4TTMgNnYzbTcgbTR2OG0wLThoNG0tOCAwdjhNNCAxOHYzaDE2djMtOG0wLTRoNG0tNCAwVjMuMTM4YTIgMiAwIDAgMC0xLjU1LTFRMTMgMiAxMCAydi4xMzgiLz48L3N2Zz4=';
                    }}
                    referrerPolicy="no-referrer"
                  />
                  {isExpanded && <span className="truncate pr-2">{league.name}</span>}
                </div>
                {isActive && <div className={`w-[5px] h-[5px] rounded-full bg-white shrink-0 ${!isExpanded ? 'absolute right-1.5 top-1.5' : ''}`} />}
              </button>
            )
          })}
        </div>
      </div>
      {isExpanded && (
        <div 
          className="fixed inset-0 top-[56px] bg-black/50 z-10 md:hidden"
          onClick={onToggle}
        />
      )}
    </>
  );
}

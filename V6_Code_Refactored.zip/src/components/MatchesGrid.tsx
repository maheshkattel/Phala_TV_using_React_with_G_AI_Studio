import React from 'react';
import { MatchCard } from './MatchCard';
import { SportEvent } from '../types';

interface MatchesGridProps {
  isLoading: boolean;
  error: string | null;
  events: SportEvent[];
  filteredEvents: SportEvent[];
  selectedLeague: string;
}

export const MatchesGrid: React.FC<MatchesGridProps> = ({
  isLoading,
  error,
  events,
  filteredEvents,
  selectedLeague
}) => {
  if (isLoading && events.length === 0) {
    return (
      <div className="col-span-full py-20 flex flex-col items-center justify-center gap-3" id="matches-loading">
        <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm text-gray-400">Loading {selectedLeague} matches...</p>
      </div>
    );
  }

  if (error && events.length === 0) {
    return (
      <div className="col-span-full py-20 flex flex-col items-center justify-center gap-2 text-center text-red-400" id="matches-error">
        <p className="text-sm font-semibold">{error}</p>
        <p className="text-xs text-gray-500">Please try another league or check your internet connection.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4" id="matches-grid">
      {filteredEvents.map(event => (
        <MatchCard key={event.id} event={event} />
      ))}
      {filteredEvents.length === 0 && (
        <div className="col-span-full py-20 flex justify-center text-center text-gray-500" id="matches-empty">
          No matches found for this league.
        </div>
      )}
    </div>
  );
};

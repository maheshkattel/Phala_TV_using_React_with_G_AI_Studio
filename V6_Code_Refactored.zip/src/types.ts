export interface TeamColors {
  primary: string;
  secondary?: string;
  text?: string;
}

export interface Team {
  id: number;
  name: string;
  slug: string;
  shortName: string;
  teamColors: TeamColors;
}

export interface Tournament {
  name: string;
  slug: string;
  uniqueTournament: {
    id: number;
    name: string;
  };
}

export interface Status {
  description: string;
  type: string;
}

export interface Score {
  current: number;
  display: number;
  period1?: number;
  period2?: number;
  normaltime?: number;
}

export interface SportEvent {
  id: number;
  startTimestamp: number;
  tournament: Tournament;
  homeTeam: Team;
  awayTeam: Team;
  status: Status;
  roundInfo?: { round: number };
  homeScore?: Score;
  awayScore?: Score;
  homeRedCards?: number;
  awayRedCards?: number;
}

export interface ApiResponse {
  events: SportEvent[];
  hasNextPage: boolean;
}
